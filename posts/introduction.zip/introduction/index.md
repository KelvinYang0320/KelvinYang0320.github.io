---
title: "Introduction"
date: 2020-06-08T08:06:25+06:00
description: Introduction to Sample Post
menu:
  sidebar:
    name: Introduction
    identifier: introduction
    weight: 10
---

Greeting! This is an introduction post. This post tests the followings:

- Hero image is in the same directory as the post.
- This post should be at top of the sidebar.
- Post author should be the same as specified in `author.yaml` file.
